#
# Topological sort using an adjacency matrix. Maximum 4 nodes.
# 
# The expected output of this program is that the 1st 4 addresses of the data segment
# are [4,0,3,2]. should take ~2000 cycles in a single cycle procesor.
#

# Adapted to RISC-V by Connor J. Link (3.1.2025)
# Per testing [3, 0, 2, 1] is the expected output (matches the original grendel.s in MARS)

.data
res:
	.word -1-1-1-1
nodes:
        .byte   97 # a
        .byte   98 # b
        .byte   99 # c
        .byte   100 # d
adjacencymatrix:
        .word   6
        .word   0
        .word   0
        .word   3
visited:
	.byte 0 0 0 0
res_idx:
        .word   3

.text
        # NEW RISCV                # ORIGINAL MIPS
	#li   sp, 0x10011000              # li $sp, 0x10011000
        li   sp, 0
        nop
        nop
        nop
        lui  sp, 0x10011         # lui $sp, 0x1001
	li   fp, 0                 # li $fp, 0
	lasw ra, pump              # la $ra pump
	j    main
        nop
        nop
        nop
pump:
        j end
        nop
        nop
        nop
        # NOTE: had to change this to pause at the end because RARS had an infinite loop for some reason here
	ebreak                     # halt


main:
        addi sp,    sp, -40        # addiu   $sp,$sp,-40
        nop
        nop
        nop
        sw   ra, 36(sp)            # sw      $31,36($sp)
        sw   fp, 32(sp)            # sw      $fp,32($sp)
        nop
        nop
        nop
        add  fp,    sp, x0         # add     $fp,$sp,$zero
        sw   x0, 24(sp)            # sw      $0,24($fp)
        j    main_loop_control
        nop
        nop
        nop

main_loop_body:
        lw   t4, 24(fp)            # lw      $4,24($fp)
        lasw ra,    trucks         # la      $ra, trucks
        j    is_visited
        nop
        nop
        nop

trucks:

        xori t2,    t2, 1          # xori    $2,$2,0x1
        nop
        nop
        nop
        andi t2,    t2, 0xff       # andi    $2,$2,0x00ff
        nop
        nop
        nop
        beq  t2,    x0, kick       # beq     $2,$0,kick
        nop
        nop
        nop
        lw   t4, 24(fp)            # lw      $4,24($fp)
                                   # ; addi    $k0, $k0,1# breakpoint
        lasw ra,    billowy        # la      $ra, billowy
        j    topsort
        nop
        nop
        nop

billowy:

kick:
        lw   t2, 24(fp)            # lw      $2,24($fp)
        nop
        nop
        nop
        addi t2,    t2, 1          # addiu   $2,$2,1
        nop
        nop
        nop
        sw   t2, 24(fp)            # sw      $2,24($fp)
main_loop_control:
        lw   t2, 24(fp)            # 01842383 # lw      $2,24($fp)
        nop
        nop
        nop
        slti t2,    t2, 4          # 0043a393 # slti    $2,$2, 4
        nop
        nop
        nop
        beq  t2,    x0, hew        # beq     $2, $zero, hew # beq, j to simulate bne 
        nop
        nop
        nop
        j    main_loop_body
        nop
        nop
        nop
hew:
        sw   x0, 28(fp)            # sw      $0,28($fp)
        j    welcome
        nop
        nop
        nop

wave:
        lw   t2, 28(fp)            # lw      $2,28($fp)
        nop
        nop
        nop
        addi t2,    t2, 1          # addiu   $2,$2,1
        nop
        nop
        nop
        sw   t2, 28(fp)            # sw      $2,28($fp)
welcome:
        lw   t2, 28(fp)            # lw      $2,28($fp)
        nop
        nop
        nop
        slti t2,    t2, 4          # slti    $2,$2,4
        nop
        nop
        nop
        xori t2,    t2, 1          # xori    $2,$2,1 # xori 1, beq to simulate bne where val in [0,1]
        nop
        nop
        nop
        beq  t2,    x0, wave       # beq     $2,$0,wave
        nop
        nop
        nop
        mv   t2,    x0             # move    $2,$0
        mv   sp,    fp             # move    $sp,$fp
        nop
        nop
        nop
        lw   ra, 36(sp)            # lw      $31,36($sp)
        lw   fp, 32(sp)            # lw      $fp,32($sp)
        addi sp, sp, 40            # addiu   $sp,$sp,40
        jr   ra                    # jr      $ra
        nop
        nop
        nop
        
interest:
        lw   t4, 24(fp)            # lw      $4,24($fp)
        nop
        nop
        nop
        lasw ra,    new            # la      $ra, new
        j    is_visited
        nop
        nop
        nop
new:
        xori t2,    t2, 1          # xori    $2,$2,0x1
        nop
        nop
        nop
        andi t2,    t2, 0x0ff      # andi    $2,$2,0x00ff
        nop
        nop
        nop
        beq  t2,    x0, tasteful   # beq     $2,$0,tasteful
        nop
        nop
        nop

        lw   t4, 24(fp)            # lw      $4,24($fp)
        lasw ra,    partner        # la      $ra, partner
        j    topsort
        nop
        nop
        nop
partner:

tasteful:
        addi t2,    fp, 28         # addiu   $2,$fp,28
        nop
        nop
        nop
        mv   t4,    t2             # move    $4,$2
        lasw ra,    badge          # la      $ra, badge
        j    next_edge
        nop
        nop
        nop
badge:
        sw   t2, 24(fp)            # sw      $2,24($fp)
        
turkey:
        lw   t3, 24(fp)            # lw      $3,24($fp)
        li   t2, -1                # li      $2,-1
        nop
        nop
        nop
        beq  t3,    t2, telling    # beq     $3,$2,telling # beq, j to simulate bne
        nop
        nop
        nop
        j    interest
        nop
        nop
        nop
telling:
        # NOTE: $v0 === $2 in MIPS
	lasw t2,    res_idx        # la      $v0, res_idx
        nop
        nop
        nop
	lw   t2,  0(t2)            # lw      $v0, 0($v0)
        nop
        nop
        nop
        addi t4,    t2, -1         # addiu   $4,$2,-1
        lasw t3,    res_idx        # la      $3, res_idx
        nop
        nop
        nop
        sw   t4,  0(t3)            # sw      $4, 0($3)
        lasw t4,    res            # la      $4, res
                                   # ; lui     $3,%hi(res_idx)
                                   # ; sw      $4,%lo(res_idx)($3)
                                   # ; lui     $4,%hi(res)
        slli t3,    t2, 2          # sll     $3,$2,2
        nop
        nop
        nop
        srli t3,    t3, 1          # srl     $3,$3,1
        nop
        nop
        nop
        srai t3,    t3, 1          # sra     $3,$3,1
        nop
        nop
        nop
        slli t3,    t3, 2          # sll     $3,$3,2
       
       	xor  t6,    ra, t2         # xor     $at, $ra, $2 # does nothing 
        nop
        or   t6,    ra, t2         # nor     $at, $ra, $2 # does nothing 
        nop
        neg  t6,    t6
        
        lasw t2,    res            # la      $2, res
        #li   a1,    0x0000ffff
        lui  a1,    0x00010
        nop
        nop
        nop
        addi a1,    a1, -1
        nop
        nop
        nop
        and  t6,    t2, a1         # andi    $at, $2, 0xffff # -1 will sign extend (according to assembler), but 0xffff won't
        nop
        nop
        nop
        add  t2,    t4, t6         # addu    $2, $4, $at
        nop
        nop
        nop
        add  t2,    t3, t2         # 007e03b3 # addu    $2,$3,$2
        nop
        lw   t3, 48(fp)            # 03042e03 # lw      $3,48($fp)
        nop
        nop
        nop
        sw   t3,  0(t2)            # 01c3a023 # sw      $3,0($2)
        mv   sp,    fp             # 00800133 # move    $sp,$fp
        nop
        nop
        nop
        lw   ra, 44(sp)            # lw      $31,44($sp)
        lw   fp, 40(sp)            # lw      $fp,40($sp)
        addi sp,    sp, 48         # addiu   $sp,$sp,48
        jr   ra                    # jr      $ra
        nop
        nop
        nop
   
topsort:
        addi sp,    sp, -48        # addiu   $sp,$sp,-48
        nop
        nop
        nop
        sw   ra, 44(sp)            # sw      $31,44($sp)
        sw   fp, 40(sp)            # sw      $fp,40($sp)
        mv   fp,    sp             # move    $fp,$sp
        nop
        nop
        nop
        sw   t4, 48(fp)            # sw      $4,48($fp)
        lw   t4, 48(fp)            # lw      $4,48($fp)
        lasw ra,    verse          # la      $ra, verse
        j    mark_visited
        nop
        nop
        nop
verse:
        addi t2,    fp, 28         # 01c40393 # addiu   $2,$fp,28
        lw   t5, 48(fp)            # 03042f03 # lw      $5,48($fp)
        nop
        mv   t4,    t2             # 00700eb3 # move    $4,$2
        lasw ra,    joyous         # la      $ra, joyous
        j    iterate_edges
        nop
        nop
        nop
joyous:

        addi t2,    fp, 28         # addiu   $2,$fp,28
        nop
        nop
        nop
        mv   t4,    t2             # move    $4,$2
        lasw ra,    whispering     # la      $ra, whispering
        j    next_edge
        nop
        nop
        nop
whispering:

        sw   t2, 24(fp)            # sw      $2,24($fp)
        nop
        j    turkey
        nop
        nop
        nop

iterate_edges:
        addi sp,    sp, -24        # addiu   $sp,$sp,-24
        nop
        nop
        nop
        sw   fp, 20(sp)            # sw      $fp,20($sp)
        mv   fp,    sp             # move    $fp,$sp
        nop
        nop
        nop
        sub  t6,    fp, sp         # subu    $at, $fp, $sp
        sw   t4, 24(fp)            # sw      $4,24($fp)
        sw   t5, 28(fp)            # sw      $5,28($fp)
        lw   t2, 28(fp)            # lw      $2,28($fp)
        nop
        nop
        nop
        sw   t2,  8(fp)            # sw      $2,8($fp)
        sw   x0, 12(fp)            # sw      $0,12($fp)
        lw   t2, 24(fp)            # lw      $2,24($fp)
        lw   t4,  8(fp)            # lw      $4,8($fp)
        nop
        lw   t3, 12(fp)            # lw      $3,12($fp)
        nop
        sw   t4,  0(t2)            # sw      $4,0($2)
        sw   t3,  4(t2)            # sw      $3,4($2)
        lw   t2, 24(fp)            # lw      $2,24($fp)
        mv   sp,    fp             # move    $sp,$fp
        nop
        nop
        nop
        lw   fp, 20(sp)            # lw      $fp,20($sp)
        addi sp,    sp, 24         # addiu   $sp,$sp,24
        jr   ra                    # jr      $ra
        nop
        nop
        nop
        
next_edge:
        addi sp,    sp, -32        # addiu   $sp,$sp,-32
        nop
        nop
        nop
        sw   ra, 28(sp)            # sw      $31,28($sp)
        sw   fp, 24(sp)            # sw      $fp,24($sp)
        nop
        nop
        nop
        add  fp,    x0, sp         # add     $fp,$zero,$sp
        nop
        nop
        nop
        sw   t4, 32(fp)            # sw      $4,32($fp)
        j    waggish
        nop
        nop
        nop

snail:
        lw   t2, 32(fp)            # lw      $2,32($fp)
        nop
        nop
        nop
        lw   t3,  0(t2)            # lw      $3,0($2)
        lw   t2, 32(fp)            # 02042383 # lw      $2,32($fp)
        nop
        nop
        nop
        lw   t2,  4(t2)            # 0043a383 # lw      $2,4($2)
        nop
        nop
        nop
        mv   t5,    t2             # move    $5,$2
        mv   t4,    t3             # move    $4,$3
        lasw ra,    induce         # la      $ra,induce
        j    has_edge
        nop
        nop
        nop
induce:
        beq  t2,    x0, quarter    # beq     $2,$0,quarter
        nop
        nop
        nop
        lw   t2, 32(fp)            # lw      $2,32($fp)
        nop
        nop
        nop
        lw   t2,  4(t2)            # lw      $2,4($2)
        nop
        nop
        nop
        addi t4,    t2, 1          # addiu   $4,$2,1
        lw   t3, 32(fp)            # lw      $3,32($fp)
        nop
        nop
        nop
        sw   t4,  4(t3)            # sw      $4,4($3)
        j    cynical
        nop
        nop
        nop

quarter:
        lw   t2, 32(fp)            # lw      $2,32($fp)
        nop
        nop
        nop
        lw   t2,  4(t2)            # lw      $2,4($2)
        nop
        nop
        nop
        addi t3,    t2, 1          # addiu   $3,$2,1
        nop
        nop
        nop
        lw   t2, 32(fp)            # lw      $2,32($fp)
        nop
        nop
        nop
        sw   t3,  4(t2)            # sw      $3,4($2)

waggish:
        lw   t2, 32(fp)            # 02042383 # lw      $2,32($fp)
        nop
        nop
        nop
        lw   t2,  4(t2)            # 0043a383 # lw      $2,4($2)
        nop
        nop
        nop
        slti t2,    t2, 4          # slti    $2,$2,4
        nop
        nop
        nop
        beq  t2,    x0, mark       # beq     $2,$zero,mark # beq, j to simulate bne 
        nop
        nop
        nop
        j    snail
        nop
        nop
        nop

mark:
        li   t2, -1                # li      $2,-1

cynical:
        mv   sp,    fp             # move    $sp,$fp
        nop
        nop
        nop
        lw   ra, 28(sp)            # lw      $31,28($sp)
        lw   fp, 24(sp)            # lw      $fp,24($sp)
        addi sp,    sp, 32         # addiu   $sp,$sp,32
        jr   ra                    # jr      $ra
        nop
        nop
        nop
has_edge:
        addi sp,    sp, -32        # addiu   $sp,$sp,-32
        nop
        nop
        nop
        sw   fp, 28(sp)            # sw      $fp,28($sp)
        mv   fp,    sp             # move    $fp,$sp
        nop
        nop
        nop
        sw   t4, 32(fp)            # sw      $4,32($fp)
        sw   t5, 36(fp)            # sw      $5,36($fp)
        lasw t2,    adjacencymatrix# la      $2,adjacencymatrix
        lw   t3, 32(fp)            # lw      $3,32($fp)
        nop
        nop
        nop
        slli t3,    t3, 2          # sll     $3,$3,2
        nop
        nop
        nop
        add  t2,    t3, t2         # addu    $2,$3,$2
        nop
        nop
        nop
        lw   t2,  0(t2)            # 0003a383 # lw      $2,0($2)
        nop
        nop
        nop
        sw   t2, 16(fp)            # 00742823 # sw      $2,16($fp)
        li   t2,  1                # li      $2,1
        nop
        nop
        nop
        sw   t2,  8(fp)            # sw      $2,8($fp)
        sw   x0, 12(fp)            # sw      $0,12($fp)
        j    measley
        nop
        nop
        nop

look:
        lw   t2,  8(fp)            # lw      $2,8($fp)
        nop
        nop
        nop
        slli t2,    t2, 1          # sll     $2,$2,1
        nop
        nop
        nop
        sw   t2,  8(fp)            # sw      $2,8($fp)
        lw   t2, 12(fp)            # lw      $2,12($fp)
        nop
        nop
        nop
        addi t2,    t2, 1          # addiu   $2,$2,1
        nop
        nop
        nop
        sw   t2, 12(fp)            # sw      $2,12($fp)
measley:
        lw   t3, 12(fp)            # lw      $3,12($fp)
        lw   t2, 36(fp)            # lw      $2,36($fp)
        nop
        nop
        nop
        slt  t2,    t3, t2         # slt     $2,$3,$2
        nop
        nop
        nop
        beq  t2,    x0, experience # beq     $2,$0,experience # beq, j to simulate bne 
        nop
        nop
        nop
        j    look
        nop
        nop
        nop
experience:
        lw   t3,  8(fp)            # lw      $3,8($fp)
        lw   t2, 16(fp)            # lw      $2,16($fp)
        nop
        nop
        nop
        and  t2,    t3, t2         # and     $2,$3,$2
        nop
        nop
        nop
        slt  t2,    x0, t2         # slt     $2,$0,$2
        nop
        nop
        nop
        andi t2,    t2, 0xff       # andi    $2,$2,0x00ff
        mv   sp,    fp             # move    $sp,$fp
        nop
        nop
        nop
        lw   fp, 28(sp)            # lw      $fp,28($sp)
        addi sp,    sp, 32         # addiu   $sp,$sp,32
        jr   ra                    # jr      $ra
        nop
        nop
        nop
        
mark_visited:
        addi sp,    sp, -32        # addiu   $sp,$sp,-32
        nop
        nop
        nop
        sw   fp, 28(sp)            # sw      $fp,28($sp)
        mv   fp,    sp             # move    $fp,$sp
        nop
        nop
        nop
        sw   t4, 32(fp)            # sw      $4,32($fp)
        li   t2,  1                # li      $2,1
        nop
        nop
        nop
        sw   t2,  8(fp)            # sw      $2,8($fp)
        sw   x0, 12(fp)            # sw      $0,12($fp)
        j    recast
        nop
        nop
        nop

example:
        lw   t2,  8(fp)            # lw      $2,8($fp)
        nop
        nop
        nop
        slli t2,    t2, 8          # sll     $2,$2,8
        nop
        nop
        nop
        sw   t2,  8(fp)            # sw      $2,8($fp)
        lw   t2, 12(fp)            # lw      $2,12($fp)
        nop
        nop
        nop
        addi t2,    t2, 1          # addiu   $2,$2,1
        nop
        nop
        nop
        sw   t2, 12(fp)            # sw      $2,12($fp)
recast:
        lw   t3, 12(fp)            # lw      $3,12($fp)
        lw   t2, 32(fp)            # lw      $2,32($fp)
        nop
        nop
        nop
        slt  t2,    t3, t2         # slt     $2,$3,$2
        nop
        nop
        nop
        beq  t2,    x0, pat        # beq     $2,$zero,pat # beq, j to simulate bne
        nop
        nop
        nop
        j    example
        nop
        nop
        nop
pat:

       	lasw t2, visited             # la      $2, visited
        nop
        nop
        nop
        sw   t2, 16(fp)              # 00742823 # sw      $2,16($fp)
        lw   t2, 16(fp)              # 01042383 # lw      $2,16($fp)
        nop
        nop
        nop
        lw   t3,  0(t2)              # 0003ae03 # lw      $3,0($2)
        lw   t2,  8(fp)              # 00842383 # lw      $2,8($fp)
        nop
        nop
        nop
        or   t3,    t3, t2           # 007e6e33 # or      $3,$3,$2
        lw   t2, 16(fp)              # 01042383 # lw      $2,16($fp)
        nop
        nop
        nop
        sw   t3,  0(t2)              # 01c3a023 # sw      $3,0($2)
        mv   sp,    fp               # 00800133 # move    $sp,$fp
        nop
        nop
        nop
        lw   fp, 28(sp)              # 01c12403 # lw      $fp,28($sp)
        addi sp,    sp, 32           # addiu   $sp,$sp,32
        jr   ra                      # jr      $ra
        nop
        nop
        nop
        
is_visited:
        addi sp,    sp, -32          # addiu   $sp,$sp,-32
        nop
        nop
        nop
        sw   fp, 28(sp)              # sw      $fp,28($sp)
        mv   fp,    sp               # move    $fp,$sp
        nop
        nop
        nop
        sw   t4, 32(fp)              # sw      $4,32($fp)
        ori  t2,    x0, 1            # ori     $2,$zero,1
        nop
        nop
        nop
        sw   t2,  8(fp)              # sw      $2,8($fp)
        sw   x0, 12(fp)              # sw      $0,12($fp)
        j    evasive
        nop
        nop
        nop

justify:
        lw   t2,  8(fp)              # lw      $2,8($fp)
        nop
        nop
        nop
        slli t2,    t2, 8            # sll     $2,$2,8
        nop
        nop
        nop
        sw   t2,  8(fp)              # sw      $2,8($fp)
        lw   t2, 12(fp)              # lw      $2,12($fp)
        nop
        nop
        nop
        addi t2,    t2, 1            # addiu   $2,$2,1
        nop
        nop
        nop
        sw   t2, 12(fp)              # 00742623 # sw      $2,12($fp)
evasive:
        lw   t3, 12(fp)              # 00c42e03 # lw      $3,12($fp)
        lw   t2, 32(fp)              # 02042383 # lw      $2,32($fp)
        nop
        nop
        nop
        slt  t2,    t3, t2           # 007e23b3 # slt     $2,$3,$2
        nop
        nop
        nop
        beq  t2,    x0,representative# beq $2,$0,representitive # beq, j to simulate bne
        nop
        nop
        nop
        j    justify
        nop
        nop
        nop
representative:

        lasw t2,    visited          # la      $2,visited
        nop
        nop
        nop
        lw   t2,  0(t2)              # 0003a383 # lw      $2,0($2)
        nop
        nop
        nop
        sw   t2, 16(fp)              # 00742823 # sw      $2,16($fp)
        lw   t3, 16(fp)              # 01042e03 # lw      $3,16($fp)
        lw   t2,  8(fp)              # 00842383 # lw      $2,8($fp)
        nop
        nop
        nop
        and  t2,    t3, t2           # and     $2,$3,$2
        nop
        nop
        nop
        slt  t2,    x0, t2           # slt     $2,$0,$2
        nop
        nop
        nop
        andi t2,    t2, 0xff         # andi    $2,$2,0x00ff
        mv   sp,    fp               # move    $sp,$fp
        nop
        nop
        nop
        lw   fp, 28(sp)              # lw      $fp,28($sp)
        addi sp,    sp, 32           # addiu   $sp,$sp,32
        jr   ra                      # jr      $ra
        nop
        nop
        nop

end:
        ebreak
        nop
        nop
        nop
