library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_textio.all;  -- For logic types I/O
library std;
--use std.env.all;                -- For hierarchical/external signals
use std.textio.all;             -- For basic I/O

-- Usually name your testbench similar to below for clarity tb_<name>
-- TODO: change all instances of tb_N_bit_Register to reflect the new testbench.
entity tb_N_bit_Register is
  generic(gCLK_HPER   : time := 10 ns;
          DATA_WIDTH  : integer := 32);   -- Generic for half of the clock cycle period
end tb_N_bit_Register;

architecture mixed of tb_N_bit_Register is

-- Define the total clock period time
constant cCLK_PER  : time := gCLK_HPER * 2;

-- We will be instantiating our design under test (DUT), so we need to specify its
-- component interface.
-- TODO: change component declaration as needed.
component N_bit_Register is
generic(N : integer := 32);
    Port ( Clk : in STD_LOGIC;
           Rst : in STD_LOGIC;
           WrEnable : in STD_LOGIC;
           Data : in STD_LOGIC_VECTOR(N-1 downto 0);
           Q : out STD_LOGIC_VECTOR(N-1 downto 0));
end component;

-- Create signals for all of the inputs and outputs of the file that you are testing
-- := '0' or := (others => '0') just make all the signals start at an initial value of zero
signal CLK, reset : std_logic := '0';

-- TODO: change input and output signals as needed.
--signal s_Clk   : std_logic := '0';
signal s_Rst   : std_logic := '0';
signal s_WrEnable : std_logic := '0';
signal s_Data   : std_logic_vector(DATA_WIDTH-1 downto 0) := x"00000000";
signal s_Q   : std_logic_vector(DATA_WIDTH-1 downto 0);

begin

  -- TODO: Actually instantiate the component to test and wire all signals to the corresponding
  -- input or output. Note that DUT0 is just the name of the instance that can be seen 
  -- during simulation. What follows DUT0 is the entity name that will be used to find
  -- the appropriate library component during simulation loading.
  DUT0: N_bit_Register
  generic map (N => DATA_WIDTH)
  port map(
            Clk     => CLK,
            Rst       => s_Rst,
            WrEnable       => s_WrEnable,
            Data     => s_Data,
            Q       => s_Q);
  --You can also do the above port map in one line using the below format: http://www.ics.uci.edu/~jmoorkan/vhdlref/compinst.html

  
  --This first process is to setup the clock for the test bench
  P_CLK: process
  begin
    CLK <= '1';         -- clock starts at 1
    wait for gCLK_HPER; -- after half a cycle
    CLK <= '0';         -- clock becomes a 0 (negative edge)
    wait for gCLK_HPER; -- after half a cycle, process begins evaluation again
  end process;

  -- This process resets the sequential components of the design.
  -- It is held to be 1 across both the negative and positive edges of the clock
  -- so it works regardless of whether the design uses synchronous (pos or neg edge)
  -- or asynchronous resets.
  P_RST: process
  begin
  	reset <= '0';   
    wait for gCLK_HPER/2;
	reset <= '1';
    wait for gCLK_HPER*2;
	reset <= '0';
	wait;
  end process;  
  
  -- Assign inputs for each test case.
  -- TODO: add test cases as needed.
  P_TEST_CASES: process
  begin
    wait for gCLK_HPER/2; -- for waveform clarity, I prefer not to change inputs on clk edges

    -- Test case 1:
    -- Initialize inputs to 0
    s_Rst   <= '1';
    s_WrEnable <= '0';
    s_Data   <= x"00000000";
    wait for gCLK_HPER*2;
    -- Expect:expecting nothing loaded into the Q because nothing has been written

    -- Test case 2:
    -- load a value into the register
    s_Rst   <= '0';
    s_WrEnable <= '1';
    s_Data   <= x"001060F5";
    wait for gCLK_HPER*2;
    -- Expect:expecting 001060F5 in the first register

    -- Test case 3:
    -- try to load a value into the register but fail
    s_Rst   <= '0';
    s_WrEnable <= '1';
    s_Data   <= x"001070F5";
    wait for gCLK_HPER*2;
    -- Expect:expecting no change so just 001060F5 in register

    -- Test case 4:
    -- load the smallest value of the register
    s_Rst   <= '0';
    s_WrEnable <= '1';
    s_Data   <= x"00000000";
    wait for gCLK_HPER*2;
    -- Expect:00000000

    -- Test case 5:
    -- load highest value of the register
    s_Rst   <= '0';
    s_WrEnable <= '1';
    s_Data   <= x"FFFFFFFF";
    wait for gCLK_HPER*2;
    -- Expect:FFFFFFFF

    -- Test case 6:
    -- reset the register
    s_Rst   <= '1';
    s_WrEnable <= '0';
    s_Data   <= x"001070F5";
    wait for gCLK_HPER*2;
    -- Expect:00000000 or N/A

    -- Test case 7:
    -- load a new value into the register
    s_Rst   <= '0';
    s_WrEnable <= '1';
    s_Data   <= x"001070F5";
    wait for gCLK_HPER*2;
    -- Expect:expecting 001070F5


    wait;
  end process;

end mixed;
