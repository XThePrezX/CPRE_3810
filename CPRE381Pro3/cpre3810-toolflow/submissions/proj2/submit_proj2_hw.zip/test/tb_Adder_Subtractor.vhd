library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_textio.all;  -- For logic types I/O
library std;
--use std.env.all;                -- For hierarchical/external signals
use std.textio.all;             -- For basic I/O

-- Usually name your testbench similar to below for clarity tb_<name>
-- TODO: change all instances of tb_Adder_Subtractor to reflect the new testbench.
entity tb_Adder_Subtractor is
  generic(gCLK_HPER   : time := 10 ns;
          DATA_WIDTH  : integer := 32);   -- Generic for half of the clock cycle period
end tb_Adder_Subtractor;

architecture mixed of tb_Adder_Subtractor is

-- Define the total clock period time
constant cCLK_PER  : time := gCLK_HPER * 2;

-- We will be instantiating our design under test (DUT), so we need to specify its
-- component interface.
-- TODO: change component declaration as needed.
component Adder_Subtractor is

generic(N : integer := 32);
    Port ( A : in std_logic_vector(N-1 downto 0);
           B : in std_logic_vector(N-1 downto 0);
           nAdd_Sub : in STD_LOGIC;
           Sum : out std_logic_vector(N-1 downto 0);
           Cout : out STD_LOGIC);

end component;

-- Create signals for all of the inputs and outputs of the file that you are testing
-- := '0' or := (others => '0') just make all the signals start at an initial value of zero
signal CLK, reset : std_logic := '0';

-- TODO: change input and output signals as needed.
signal s_A   : std_logic_vector(DATA_WIDTH-1 downto 0) := x"00000000";
signal s_B   : std_logic_vector(DATA_WIDTH-1 downto 0) := x"00000000";
signal s_nAdd_Sub : std_logic := '0';
signal s_Sum   : std_logic_vector(DATA_WIDTH-1 downto 0);
signal s_Cout   : STD_LOGIC;

begin

  -- TODO: Actually instantiate the component to test and wire all signals to the corresponding
  -- input or output. Note that DUT0 is just the name of the instance that can be seen 
  -- during simulation. What follows DUT0 is the entity name that will be used to find
  -- the appropriate library component during simulation loading.
  DUT0: Adder_Subtractor
  generic map (N => DATA_WIDTH)
  port map(
            A     => s_A,
            B       => s_B,
            nAdd_Sub       => s_nAdd_Sub,
            Sum     => s_Sum,
            Cout       => s_Cout);
  --You can also do the above port map in one line using the below format: http://www.ics.uci.edu/~jmoorkan/vhdlref/compinst.html

  
  --This first process is to setup the clock for the test bench
  P_CLK: process
  begin
    CLK <= '1';         -- clock starts at 1
    wait for gCLK_HPER; -- after half a cycle
    CLK <= '0';         -- clock becomes a 0 (negative edge)
    wait for gCLK_HPER; -- after half a cycle, process begins evaluation again
  end process;

  -- This process resets the sequential components of the design.
  -- It is held to be 1 across both the negative and positive edges of the clock
  -- so it works regardless of whether the design uses synchronous (pos or neg edge)
  -- or asynchronous resets.
  P_RST: process
  begin
  	reset <= '0';   
    wait for gCLK_HPER/2;
	reset <= '1';
    wait for gCLK_HPER*2;
	reset <= '0';
	wait;
  end process;  
  
  -- Assign inputs for each test case.
  -- TODO: add test cases as needed.
  P_TEST_CASES: process
  begin
    wait for gCLK_HPER/2; -- for waveform clarity, I prefer not to change inputs on clk edges

    -- Test case 1: Initalize all values to 0
    s_A   <= x"00000000"; 
    s_B   <= x"00000000"; 
    s_nAdd_Sub <= '0';
    wait for gCLK_HPER*2;
    -- Expect: 0 + 0 = 0

    -- Test case 2: Add two basic values (3+5)
    s_A   <= x"00000003"; 
    s_B   <= x"00000005"; 
    s_nAdd_Sub <= '0';
    wait for gCLK_HPER*2;
    -- Expect: 3 + 5 = 8

    -- Test case 3: Add two more complex values values
    s_A   <= x"00010101"; 
    s_B   <= x"000F5020"; 
    s_nAdd_Sub <= '0';
    wait for gCLK_HPER*2;
    -- Expect: 00010101 + 000F5020 = 00105121

    -- Test case 4: Test that s_Cout works correctly
    s_A   <= x"FFFFFFFF"; 
    s_B   <= x"00000001"; 
    s_nAdd_Sub <= '0';
    wait for gCLK_HPER*2;
    -- Expect: 00000000 and Cout = 1

    -- Test case 5: Test that when Add_sub = 1 that A-B (ex. 6-5=1)
    s_A   <= x"00000006"; 
    s_B   <= x"00000005"; 
    s_nAdd_Sub <= '1';
    wait for gCLK_HPER*2;
    -- Expect: should get s_Sum = 1 and s_Cout = 1

    -- Test case 6: subtract to a big negative number
    s_A   <= x"00000006"; 
    s_B   <= x"0000000F"; 
    s_nAdd_Sub <= '1';
    wait for gCLK_HPER*2;
    -- Expect: should get s_Sum = -9 and s_Cout = 0

    -- Test case 7: subtract to a and check for c_out
    s_A   <= x"00000001"; 
    s_B   <= x"80000000"; --biggest negative value in hex
    s_nAdd_Sub <= '1';
    wait for gCLK_HPER*2;
    -- Expect: should get s_Sum = 80000001

    -- Test case 8: Initalize all values to 0 just to double check that c_out goes back to 0
    s_A   <= x"00000000"; 
    s_B   <= x"00000000"; 
    s_nAdd_Sub <= '0';
    wait for gCLK_HPER*2;
    -- Expect: 0 + 0 = 0



    wait;
  end process;

end mixed;
